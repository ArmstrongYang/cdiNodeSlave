/*****************************************************************

File			:	YD-Module\BLE_DA14580\BLE.h
Fuction		:	
Author		:	@hiyangdong
Version		:	V1.0
Time			:	30 Nov. 2015

*****************************************************************/

#ifndef _MAIN_H_
#define _MAIN_H_

#include "stm32f0xx_hal.h"
#include "usart.h"
#include "gpio.h"

#include "flash_if.h"
#include "xmodem.h"
#include "boot.h"

extern UART_HandleTypeDef UartHandle;

#endif
