/*****************************************************************

File			:	YD-Module\BLE_DA14580\BLE.h
Fuction		:	
Author		:	@hiyangdong
Version		:	V1.0
Time			:	30 Nov. 2015

*****************************************************************/

#ifndef _ANOSERIAL_H_
#define _ANOSERIAL_H_

#include "stm32l1xx_hal.h"

void ANO_DT_Send_Power(void);

#endif
