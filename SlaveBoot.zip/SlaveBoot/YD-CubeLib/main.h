/**
****************************************************************

File		:	main.h
Author	:	@hiyangdong
Version	:	V1.0
date		:	2015-05-19 19:04:20
brief		:	main header

*****************************************************************
*/

#ifndef _MAIN_H_
#define _MAIN_H_


#include "cLEDs.h"
#include "sLEDs.h"
#include "sKey.h"

#endif
