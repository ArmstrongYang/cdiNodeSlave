/**
****************************************************************

File	:	cWIFI.h
Author	:	@hiyangdong
Version	:	V1.0
date	:	2015-05-13
brief	:	header file

*****************************************************************
*/

#ifndef _CWIFI_H_
#define _CWIFI_H_

#include "stm32f0xx_hal_def.h"

void cWIFI_Init(void);

#endif
