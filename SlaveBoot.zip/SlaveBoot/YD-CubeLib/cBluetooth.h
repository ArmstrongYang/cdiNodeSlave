/**
****************************************************************

File	:	cBluetooth.h
Author	:	@hiyangdong
Version	:	V1.0
date	:	2015-05-13
brief	:	header file

*****************************************************************
*/

#ifndef _CBLUETOOTH_H_
#define _CBLUETOOTH_H_

#include "stm32f0xx_hal_def.h"

void cBT_Init(void);

#endif
